import telebot
from telebot import types
import requests
from bs4 import BeautifulSoup
import time
import logging
from datetime import datetime, timedelta
from threading import Thread

# Настройка логирования
logging.basicConfig(level=logging.INFO)

TOKEN = '6701431134:AAF1jJ1BwVfE1leAHNYr1N6oQKPB9FYeiXo'
bot = telebot.TeleBot(TOKEN)

subscribed_chats = set()
# Список для хранения отправленных задач
sent_tasks = []

def fetch_tasks():
    try:
        response = requests.get('https://freelance.habr.com/tasks')
        soup = BeautifulSoup(response.text, 'html.parser')
        tasks = soup.find_all('div', class_='task__title')
        all_tasks_today = [f'{task.text.strip()} | https://freelance.habr.com{task.find("a").get("href")}' for task in tasks]
        return all_tasks_today
    except Exception as ex:
        logging.error('Error fetching tasks: %s', ex)
        return []

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Используй /subscribe для подписки на уведомления.")

@bot.message_handler(commands=['subscribe'])
def subscribe(message):
    subscribed_chats.add(message.chat.id)
    logging.info(f"Chat {message.chat.id} subscribed.")
    bot.reply_to(message, "Вы подписались на уведомления.")

@bot.message_handler(commands=['unsubscribe'])
def unsubscribe(message):
    if message.chat.id in subscribed_chats:
        subscribed_chats.remove(message.chat.id)
        logging.info(f"Chat {message.chat.id} unsubscribed.")
        bot.reply_to(message, "Вы отписались от уведомлений.")
    else:
        bot.reply_to(message, "Вы не были подписаны на уведомления.")

def check_and_notify():
    while True:
        current_time = datetime.now()
        if current_time.hour == 0 and current_time.minute == 0:
            # Сброс отправленных задач каждый день в 00:00
            global sent_tasks
            sent_tasks = []
            time.sleep(60)  # Предотвращение многократного сброса в течение минуты

        new_tasks = fetch_tasks()
        if new_tasks:
            unsent_tasks = [task for task in new_tasks if task not in sent_tasks]
            if unsent_tasks:
                logging.info('New tasks found: %s', unsent_tasks)
                for chat_id in list(subscribed_chats):
                    try:
                        for new_task in unsent_tasks:
                            logging.info(f"Sending task to chat {chat_id}: {new_task}")
                            bot.send_message(chat_id, new_task)
                        sent_tasks.extend(unsent_tasks)
                    except Exception as e:
                        logging.error(f"Failed to send message to chat {chat_id}: {e}")
            else:
                logging.info('No new tasks.')
        else:
            logging.info('No new tasks or failed to fetch tasks.')
        time.sleep(300)  # Пауза 5 минут

if __name__ == '__main__':
    t = Thread(target=check_and_notify)
    t.start()
    bot.polling(none_stop=True, timeout=60)
